<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['userdata_missing_username'] = 'Bir kullanıcı adı girmediniz. Lütfen bir tane girin.';
$l['userdata_banned_username'] = 'Girdiğiniz kullanıcı adı kayıtlı olmayabilir. Lütfen farklı bir kullanıcı adı girin.';
$l['userdata_bad_characters_username'] = 'Girdiğiniz kullanıcı adı hatalı karakterler içeriyor. Lütfen farklı bir kullanıcı adı girin.';
$l['userdata_invalid_username_length'] = 'Girdiğiniz kullanıcı adı geçersiz. Lütfen {1} ve {2} karakterleri arasında bir kullanıcı adı girin.';
$l['userdata_invalid_usertitle_length'] = 'Girdiğiniz özel kullanıcı başlığı geçersiz uzunlukta. Lütfen {1} karakterden uzun olmayan bir başlık girin.';
$l['userdata_username_exists'] = 'Girdiğiniz kullanıcı adı zaten var. Lütfen farklı bir kullanıcı adı girin.';

$l['userdata_invalid_password_length'] = 'Girdiğiniz şifre geçersiz. Lütfen {1} ve {2} karakterleri arasında bir şifre girin.';
$l['userdata_no_complex_characters'] = 'Girdiğiniz şifre yeterince karmaşık değil. Lütfen en az {1} karakter uzunluğunda olan ve bir büyük harf, küçük harf ve bir sayı içeren bir şifre girin.';
$l['userdata_passwords_dont_match'] = 'Onay olarak girdiğiniz şifre orijinal şifreyle eşleşmiyor. Lütfen şifrenizi doğru bir şekilde onaylayın.';
$l['userdata_bad_password_security'] = 'Girdiğiniz şifre, kullanıcı adınıza veya e-posta adresinize benzer. Lütfen daha güçlü bir şifre girin.';

$l['userdata_missing_email'] = 'Bir e-posta adresi girmediniz. Lütfen bir tane girin.';
$l['userdata_invalid_email_format'] = 'Girdiğiniz e-mail adresi geçersiz. Geçerli bir e-mail adresi giriniz.';
$l['userdata_emails_dont_match'] = 'Onay olarak girdiğiniz e-posta adresi, orijinal adresi ile eşleşmiyor. Lütfen e-posta adresinizi doğru bir şekilde onaylayın.';
$l['userdata_banned_email'] = "Girdiğiniz e-posta adresinin kullanılmasına izin verilmiyor. Lütfen farklı bir e-posta adresi girin.";
$l['userdata_email_already_in_use'] = "Daha önce başka bir üye tarafından kullanımda olan bir e-posta adresi girdiniz. Lütfen farklı bir e-posta adresi girin.";

$l['userdata_dob_required'] = "Doğum tarihinizi seçmediniz. Lütfen devam etmek için doğum tarihinizi seçin - doğum gününüzü ve yaşınızı diğer kullanıcılardan gizleyebilirsiniz.";
$l['userdata_invalid_website'] = 'Girdiğiniz web sitesi adresi geçersiz. Lütfen geçerli bir web sitesi adresi girin veya alanı boş bırakın.';
$l['userdata_invalid_icq_number'] = 'Girdiğiniz ICQ numarası geçersiz. Lütfen geçerli bir ICQ numarası girin veya alanı boş bırakın.';
$l['userdata_invalid_birthday'] = 'Girdiğiniz doğum günü geçersiz. Lütfen geçerli bir doğum günü girin veya alanı boş bırakın.';
$l['userdata_invalid_birthday_coppa'] = 'Yaşınızı doğrulamak için lütfen doğduğunuz yılı girin. Profil seçeneklerinde Yaşınızı ve Doğum Tarihinizi gizleyebilirsiniz.';
$l['userdata_invalid_birthday_coppa2'] = 'Bu mesaj panosuna üye olmak için en az 13 yaşında olmanız gerekir. Lütfen bir Yöneticiye başvurun.';
$l['userdata_invalid_birthday_privacy'] = 'Lütfen geçerli bir doğum günü mahremiyeti seçeneği seçin.';
$l['userdata_invalid_referrer'] = 'Girdiğiniz yönlendirici mevcut değil. Lütfen mevcut bir yönlendirici girin veya alanı boş bırakın.';
$l['userdata_invalid_language'] = 'Seçtiğiniz dil mevcut değil. Lütfen mevcut bir dil seçiniz.';
$l['userdata_invalid_style'] = 'Seçtiğiniz stil geçersiz. Lütfen geçerli bir stil seçin.';
$l['userdata_away_too_long'] = 'Belirttiğiniz Sebep çok uzun. Bu alan için en fazla 200 karakter girilebilir. Lütfen {1} karakterlerini bu alandan kaldırın.';
$l['userdata_missing_returndate'] = 'Belirttiğiniz Dönüş Tarihi, bir veya daha fazla alanın eksik. Lütfen gün, ay ve yıl alanlarını doldurduğunuzdan emin olun.';
$l['userdata_missing_required_profile_field'] = '"{1}" alanı için bir seçenek girmediniz. Lütfen bu alanı doldurunuz veya bir değer seçiniz.';
$l['userdata_bad_profile_field_value'] = '"{1}" alanı için geçerli bir değer girmediniz. Lütfen devam etmeden önce geçerli bir değer girin.';
$l['userdata_bad_profile_field_values'] = '"{1}" alanı için geçerli bir seçenek seçmediniz. Lütfen sunulan seçeneklerden bir değer seçin.';
$l['userdata_max_limit_reached'] = '"{1}" alanı için geçersiz sayıda karakter girdiniz. Lütfen bu alanı en fazla {2} karakterle doldurun.';
$l['userdata_invalid_checkfield'] = "Bu formun spam bot tarafından gönderildiği tespit edildi. Bu hatalıysa, lütfen yöneticiye başvurun.";
$l['userdata_invalid_postnum'] = "Girdiğiniz gönderi sayısı geçersiz. Lütfen geçerli bir posta numarası girin veya alanı boş bırakın.";
$l['userdata_invalid_threadnum'] = "Girdiğiniz iş parçacığı sayısı geçersiz. Lütfen geçerli bir diş sayısı girin veya alanı boş bırakın.";

$l['userdata_too_many_sig_images'] = "Maalesef, çok fazla resim içerdiğinden imzanızı güncelleyemiyoruz. Lütfen devam etmek için bazı görüntüleri imzanızdan kaldırın.";
$l['userdata_too_many_sig_images2'] = "<strong>Not:</strong> İmzalar için maksimum resim miktarı {1}.";
$l['userdata_sig_too_long'] = "İmzanızı güncelleyemezsiniz çünkü çok uzun. İmzalar için maksimum uzunluk {1} karakterdir. ";
$l['userdata_sig_remove_chars_plural'] = "Lütfen {1} karakterleri kaldırın ve tekrar deneyin.";
$l['userdata_sig_remove_chars_singular'] = "Lütfen 1 karakteri kaldırın ve tekrar deneyin.";
