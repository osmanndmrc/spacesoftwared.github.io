<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 * Website: http://www.mybb.com
 * License: http://www.mybb.com/about/license
 *
 */

$l['hello'] = 'Merhaba Dünya!';
$l['hello_add'] = 'Ekle';
$l['hello_add_message'] = 'Mesaj Ekle';
$l['hello_empty'] = 'Hiçbir mesaj bulunamadı.';
$l['hello_message_empty'] = 'Mesaj boş olamaz.';
$l['hello_done'] = 'Yeni mesaj başarıyla eklendi.';