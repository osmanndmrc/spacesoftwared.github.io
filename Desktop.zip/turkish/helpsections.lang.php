<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */
 
// Help Section 1
$l['s1_name'] = "Kullanıcı Bakım ve Onarımı";
$l['s1_desc'] = "Forum hesabı için basit bakım ve onarım dersleri.";

// Help Section 2
$l['s2_name'] = "Mesaj Gönderme";
$l['s2_desc'] = "Mesaj gönderme, cevaplama ve forumun basit kullanımı.";
