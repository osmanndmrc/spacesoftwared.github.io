<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['error_no_connection'] = "Sunucu bağlantısında bir hata oluştu: ";
$l['error_no_message'] = "Belirtilen bir mesaj yok.";
$l['error_no_subject'] = "Belirtilen bir başlık yok.";
$l['error_no_recipient'] = "Belirtilen bir alıcı yok.";
$l['error_not_sent'] = "Php mail fonksiyonu kullanılarak mail göndermeye çalışılırken bir hata oluştu.";
$l['error_status_missmatch'] = "Sunucu istatistikleri beklenen sonuç ile eşleşmedi: ";
$l['error_data_not_sent'] = "Bu veri sunucuya gönderilemedi: ";

$l['error_occurred'] = "Bir veya daha fazla hata oluştu. Lütfen devam etmeden önce hataları düzeltiniz.<br />";
