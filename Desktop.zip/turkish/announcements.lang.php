<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['nav_announcements'] = "Forum Duyurusu";
$l['announcements'] = "Duyuru";
$l['forum_announcement'] = "Forum Duyurusu: {1}";
$l['error_invalidannouncement'] = "Belirtilen duyuru geçersiz.";

$l['announcement_edit'] = "Bu duyuruyu düzenle";
$l['announcement_qdelete'] = "Bu duyuruyu sil";
$l['announcement_quickdelete_confirm'] = "Bu duyuruyu silmek istediğinize emin misiniz?";

