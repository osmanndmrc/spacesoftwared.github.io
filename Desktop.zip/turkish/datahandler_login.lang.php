<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['logindata_invalidpwordusername'] = "Geçersiz kullanıcı adı/şifre girdiniz. <br /><br />Eğer şifrenizi unuttuysanız, lütfen <a href=\"member.php?action=lostpw\">yeni şifre isteyiniz</a>.";
$l['logindata_invalidpwordusernameemail'] = "Geçersiz e-posta/şifre girdiniz. <br /><br />Eğer şifrenizi unuttuysanız, lütfen <a href=\"member.php?action=lostpw\">yeni şifre isteyiniz</a>.";
$l['logindata_invalidpwordusernamecombo'] = "Geçersiz kullanıcı adı/şifre veya e-posta girdiniz. <br /><br />Eğer şifrenizi unuttuysanız, lütfen <a href=\"member.php?action=lostpw\">yeni şifre isteyiniz</a>.";

$l['logindata_regimageinvalid'] = "Girdiğiniz resim doğrulama kodu hatalı. Lütfen kodu tam olarak resimde göründüğü gibi girin.";
$l['logindata_regimagerequired'] = "Giriş işlemine devam etmek için lütfen resim doğrulama kodunu yazın. Lütfen kodu tam olarak resimde göründüğü gibi girin.";
