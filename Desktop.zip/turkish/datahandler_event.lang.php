<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['eventdata_missing_name'] = 'Etkinliğin adı eksik. Lütfen bir etkinlik adı girin.';
$l['eventdata_missing_description'] = 'Etkinliğin açıklaması eksik. Lütfen bir etkinlik açıklaması girin.';

$l['eventdata_invalid_start_date'] = 'Girdiğiniz etkinlik başlangıç tarihi geçersiz. Gün, ay ve yılı belirlediğinizden ve girdiğiniz günün belirli bir ay için geçerli olduğundan emin olmanız gerekir.';
$l['eventdata_invalid_start_year'] = "Etkinlikler sadece önümüzdeki 5 yıl içinde yaratılabilir. Lütfen listeden makul bir başlangıç yılı seçin.";
$l['eventdata_invalid_start_month'] = 'Girdiğiniz başlangıç ayı geçerli bir ay değil. Lütfen geçerli bir başlangıç ayı girin.';

$l['eventdata_invalid_end_date'] = 'Girdiğiniz etkinlik bitiş tarihi geçersiz. Gün, ay ve yılı belirlediğinizden ve girdiğiniz günün belirli bir ay için geçerli olduğundan emin olmanız gerekir.';
$l['eventdata_invalid_end_year'] = "Etkinlikler sadece önümüzdeki 5 yıl içinde yaratılabilir. Lütfen listeden makul bir bitiş yılı seçin.";
$l['eventdata_invalid_end_month'] = 'Girdiğiniz bitiş ayı geçerli bir ay değil. Lütfen geçerli bir son ay girin.';
$l['eventdata_invalid_end_day'] = 'Girdiğiniz bitiş günü geçerli bir gün değil. Seçtiğiniz gün muhtemelen bu aydaki gün sayısından büyük.';

$l['eventdata_cant_specify_one_time'] = "Bir etkinlik başlangıç saati belirtiyorsanız, bir etkinlik bitiş saati girmeniz gerekir.";
$l['eventdata_start_time_invalid'] = "Girdiğiniz başlangıç zamanı geçersiz. Geçerli örnekler 12: 00-12: 00, 00: 01'dir.";
$l['eventdata_end_time_invalid'] = "Girdiğiniz bitiş zamanı geçersiz. Geçerli örnekler 12: 00-12: 00, 00: 01'dir.";
$l['eventdata_invalid_timezone'] = "Bu etkinlik için seçtiğiniz saat dilimi geçersiz.";
$l['eventdata_end_in_past'] = "Etkinliğinizin bitiş tarihi veya saati başlangıç tarihinden veya saatinden önce.";

$l['eventdata_only_ranged_events_repeat'] = "Yalnızca aralıklı etkinlikler (başlangıç ve bitiş tarihi olan etkinlikler) tekrar edebilir.";
$l['eventdata_invalid_repeat_day_interval'] = "Geçersiz bir gün tekrarlama aralığı girdiniz.";
$l['eventdata_invalid_repeat_week_interval'] = "Geçersiz bir hafta tekrar aralığı girdiniz.";
$l['eventdata_invalid_repeat_weekly_days'] = "Bu etkinliğin gerçekleşmesi için hafta içi günleri seçmediniz.";
$l['eventdata_invalid_repeat_month_interval'] = "Geçersiz bir ay tekrar aralığı girdiniz.";
$l['eventdata_invalid_repeat_year_interval'] = "Geçersiz bir yıl tekrarlama aralığı girdiniz.";
$l['eventdata_event_wont_occur'] = "Etkinlik tekrarlama ayarlarıyla birlikte başlangıç ve bitiş zamanlarını kullanarak bu olay gerçekleşmez.";

$l['eventdata_no_permission_private_event'] = "Özel etkinlikler yayınlama izniniz yok.";
