<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['warnings_reached_max_warnings_day'] = '"Günde verebileceğiniz uyarı sayısı sınırına ulaştığınız için kimseyi uyaramazsınız. <br /><br /> Günde verebileceğiniz azami uyarı sayısı {1}'dir."';
$l['warnings_error_invalid_user'] = "Seçilen kullanıcı mevcut değil.";
$l['warnings_error_invalid_post'] = "Seçilen mesaj mevcut değil.";
$l['warnings_error_cannot_warn_self'] = "Kendi uyarı seviyene ekleyemezsin.";
$l['warnings_error_user_reached_max_warning'] = "Bu kullanıcı zaten maksimum uyarı seviyesine ulaştığı için uyarılamaz.";
$l['warnings_error_no_note'] = "Bu uyarı için herhangi bir idari not girmediniz.";
$l['warnings_error_invalid_type'] = "Geçersiz bir uyarı türü seçtiniz.";
$l['warnings_error_cant_custom_warn'] = "Kullanıcılara özel uyarılar verme izniniz yok.";
$l['warnings_error_no_custom_reason'] = "Özel uyarınız için bir neden girmediniz.";
$l['warnings_error_invalid_custom_points'] = "Bu kullanıcı uyarı seviyesine eklemek için geçerli bir puan girmediniz. 0'dan büyük ancak {1} 'den büyük olmayan bir sayısal değer girmeniz gerekir.";
$l['warnings_error_invalid_expires_period'] = "Geçersiz bir sona erme türü girdiniz.";
