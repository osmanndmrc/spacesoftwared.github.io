<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['post_icons'] = "Mesaj İkonları";
$l['add_post_icon'] = "Yeni Mesaj İkonu Ekle";
$l['add_post_icon_desc'] = "Buradan yeni mesaj ikonu ekleyebilirsiniz.";
$l['add_multiple_post_icons'] = "Çoklu Mesaj İkonu Ekle";
$l['add_multiple_post_icons_desc'] = "Buradan çoklu şekilde yeni mesaj ikonları ekleyebilirsiniz.";
$l['edit_post_icon'] = "Mesaj İkonu Düzenle";
$l['edit_post_icon_desc'] = "Buradan mesaj ikonunu düzenleyebilirsiniz.";
$l['manage_post_icons'] = "Mesaj İkonlarını Yönet";
$l['manage_post_icons_desc'] = "Bu bölüm mesaj ikonlarınızı düzenlemenize, silmenize ve yönetmenize izin verir.";

$l['name_desc'] = "Bu mesaj ikonu için isimdir.";
$l['image_path'] = "Resim yolu";
$l['image_path_desc'] = "Bu, mesaj ikonu resimleri için bir yoldur. Farklı temaların mesaj simgesi yolunu belirtmek için temanın resim yolunu temsil eden <strong>{theme}</strong> kodunu kullanın.";
$l['save_post_icon'] = "Mesaj İkonunu Kaydet";
$l['reset'] = "Yenile";

$l['path_to_images'] = "Resimlerin Yolu";
$l['path_to_images_desc'] = "Bu resimlerin içinde olacağı klasörün yoludur.";
$l['show_post_icons'] = "Mesaj İkonlarını Göster";
$l['image'] = "Resim";
$l['add'] = "Ekle?";
$l['save_post_icons'] = "Mesaj İkonlarını Kaydet";

$l['no_post_icons'] = "Şu anda forumunuzda mesaj ikonu yok";

$l['error_missing_name'] = "Bu mesaj ikonu için isim girmediniz.";
$l['error_missing_path'] = "Bu mesaj ikonu için resim yolu girmediniz.";
$l['error_missing_path_multiple'] = "Bir resim yolu girmediniz";
$l['error_invalid_path'] = "Uygun resim yolu girmediniz";
$l['error_no_images'] = "Belirtilen klasörde mesaj ikonu bulunmamaktadır ya da klasördeki tüm mesaj ikonları zaten eklenmiş.";
$l['error_none_included'] = "İçermesi için herhangi mesaj ikonu seçmediniz.";
$l['error_invalid_post_icon'] = "Belirtilen mesaj ikonu mevcut değil.";

$l['success_post_icon_added'] = "Mesaj ikonu başarılı şekilde eklendi.";
$l['success_post_icons_added'] = "Seçilen mesaj ikonları başarılı şekilde eklendi.";
$l['success_post_icon_updated'] = "Mesaj ikonu başarılı şekilde güncellendi.";
$l['success_post_icon_deleted'] = "Belirtilen mesaj ikonu başarılı şekilde silindi.";

$l['confirm_post_icon_deletion'] = "Bu mesaj ikonunu silmek istediğinizden eminmisiniz?";
