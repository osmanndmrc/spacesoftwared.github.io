<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['forums_and_posts'] = "Forumlar &amp; Mesajlar";

$l['forum_management'] = "Forum Yönetimi";
$l['forum_announcements'] = "Forum Duyuruları";
$l['moderation_queue'] = "Moderasyon Sorgusu";
$l['attachments'] = "Eklentiler";

$l['can_manage_forums'] = "Forumları Yönetebilir mi?";
$l['can_manage_forum_announcements'] = "Forum Duyurularını Yönetebilir mi?";
$l['can_moderate'] = "Mesajları, Konuları ve Eklentileri Yönetebilir mi?";
$l['can_manage_attachments'] = "Eklentileri Yönetebilir mi?";
