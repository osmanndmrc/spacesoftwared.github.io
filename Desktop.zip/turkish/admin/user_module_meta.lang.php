<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['users_and_groups'] = "Kullanıcılar &amp; Gruplar";

$l['users'] = "Kullanıcılar";
$l['awaiting_activation'] = "Aktivasyon Bekleyenler";
$l['groups'] = "Gruplar";
$l['user_titles'] = "Kullanıcı Başlıkları";
$l['banning'] = "Yasaklama";
$l['admin_permissions'] = "Admin İzinleri";
$l['mass_mail'] = "Toplu Mail";
$l['group_promotions'] = "Grup Terfileri";

$l['can_manage_users'] = "Kullanıcıları Yönetebilir Mi?";
$l['can_manage_awaiting_activation'] = "Aktivasyon Bekleyenler Yönetilebilir Mi?";
$l['can_manage_user_groups'] = "Kullanıcı Gruplarını Yönetebilir Mi?";
$l['can_manage_user_titles'] = "Kullanıcı Başlıklarını Yönetebilir Mi?";
$l['can_manage_user_bans'] = "Kullanıcı Yasaklamayı Yönetebilir Mi?";
$l['can_manage_admin_permissions'] = "Admin İzinlerini Yönetebilir Mi?";
$l['can_send_mass_mail'] = "Toplu Mail Gönderebilir Mi?";
$l['can_manage_group_promotions'] = "Grup Terfilerini Yönetebilir Mi?";
