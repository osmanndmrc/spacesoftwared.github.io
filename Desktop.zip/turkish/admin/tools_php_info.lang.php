<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['php_info'] = "PHP Bilgisi";
$l['browser_no_iframe_support'] = "Tarayıcınız iframeleri desteklemiyor";

