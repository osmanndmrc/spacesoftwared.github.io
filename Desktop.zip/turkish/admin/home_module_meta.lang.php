<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['home'] = "Ana Sayfa";

$l['dashboard'] = "Başlangıç";
$l['preferences'] = "Tercihler";
$l['mybb_credits'] = "MyBB Ekibi";

$l['add_new_forum'] = "Yeni Forum Ekle";
$l['search_for_users'] = "Kullanıcı Ara";
$l['themes'] = "Temalar";
$l['templates'] = "Şablonlar";
$l['plugins'] = "Pluginler/Eklentiler";
$l['database_backups'] = "Veritabanı Yedekleri";
$l['quick_access'] = "Hızlı Erişim";
$l['online_admins'] = "Çevirimiçi Adminler";
$l['ipaddress'] = "İP Adresi:";
$l['mybb_documentation'] = "MyBB Dökümanlar";

