<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['nav_calendar'] = "Takvim";
$l['nav_viewevent'] = "Etkinlikleri Görüntüle";
$l['nav_dayview'] = "Güne Bakış";
$l['nav_addevent'] = "Etkinlik Ekle";
$l['nav_editevent'] = "Etkinliği Düzenle";
$l['nav_move_event'] = "Etkinliği Taşı";

$l['calendar_disabled'] = "Takvim işlevini, Yönetici tarafından devre dışı bırakıldığı için kullanamazsınız.";

// In some languages these months need to be slightly different than those defined in global.lang.php
$l['alt_month_1'] = "Ocak";
$l['alt_month_2'] = "Şubat";
$l['alt_month_3'] = "Mart";
$l['alt_month_4'] = "Nisan";
$l['alt_month_5'] = "Mayıs";
$l['alt_month_6'] = "Haziran";
$l['alt_month_7'] = "Temmuz";
$l['alt_month_8'] = "Ağustos";
$l['alt_month_9'] = "Eylül";
$l['alt_month_10'] = "Ekim";
$l['alt_month_11'] = "Kasım";
$l['alt_month_12'] = "Aralık";

$l['add_private_event'] = "Özel Etkinlik Ekleyin";
$l['add_public_event'] = "Genel Etkinlik Ekle";

$l['calendar'] = "Takvim";

$l['jump_month'] ="Aya atla:";

$l['birthdays_on_day'] = "Doğum günleri {1}";
$l['birthdayhidden'] = "Gizli";

$l['event'] = "Etkinlik";
$l['events'] = "Etkinlikler";
$l['add_event'] = "Etkinlik ekle";
$l['event_date'] = "Etkinlik Tarihi:";
$l['event_recurring_start_date'] = "Başlangıç Tarihi:";
$l['event_recurring_end_date'] = "Bitiş Tarihi:";
$l['event_recurring_repeat_days'] = "Etkinlik Tekrarları Açık:";
$l['event_name'] = "Etkinlik Adı:";
$l['event_details'] = "Etkinlik Detayları:";
$l['event_options'] = "Ayarlar:";
$l['private_option'] = "<b>Özel</b> Bu etkinliği yalnızca siz görebileceksiniz. (Sadece kayıtlı kullanıcılar).";
$l['delete_option'] = "<b>Sil:</b> Bu etkinliği sil.";
$l['post_event'] = "Etkinlik Sonrası";
$l['day_view'] = "Güne Bak";
$l['birthday'] = "Doğum günü";
$l['birthdays'] = "Doğum günleri";
$l['event_author'] = "Etkinlik Yazarı:";
$l['edit_event'] = "Etkinliği Düzenle";
$l['view_event'] = "Etkinliği Görüntüle";
$l['no_events'] = "Bu gün onunla ilişkili hiçbir etkinlik yok.<p><a href=\"calendar.php?action=addevent&amp;calendar={1}&amp;day={2}&amp;month={3}&amp;year={4}\">Etkinlik Gönder</a>.</p>";
$l['years_old'] = "{1} Yıl Önce";
$l['alt_edit'] = "Bu etkinliği düzenle";
$l['alt_delete'] = "Bu etkinliği sil";
$l['moderator_options'] = "Moderatör Seçenekleri";
$l['approve_event'] = "Etkinliği Onayla";
$l['unapprove_event'] = "Etkinliği Onaylama";
$l['move_event'] = "Etkinliği Taşı";
$l['repeats_every_day'] = "Her gün tekrarlar";
$l['repeats_every_x_days'] = "Her {1} günde bir tekrar eder";
$l['repeats_on_weekdays'] = "Pazartesiden cumaya tekrarlar";
$l['every_week_on_days'] = "{1} tarihinde her hafta tekrar eder";
$l['every_week'] = "Her hafta tekrarlar";
$l['every_x_weeks_on_days'] = "{2} tarihinde her {1} haftada bir tekrar eder";
$l['every_x_weeks'] = "Her {1} haftada bir tekrarlar";
$l['every_month_on_day'] = "Her ayın {1} <br /> gününde tekrarlar";
$l['every_x_months_on_day'] = "Her {2} ayın {1} <br /> günündeki tekrarlar";
$l['every_month_on_weekday'] = "Her ayın {1} {2} <br /> tarihinde tekrar eder";
$l['every_x_months_on_weekday'] = "Her {3} ayın {1} {2} <br /> tarihinde tekrar eder";
$l['weekday_occurance_1'] = "ilk";
$l['weekday_occurance_2'] = "ikinci";
$l['weekday_occurance_3'] = "üçüncü";
$l['weekday_occurance_4'] = "dördüncü";
$l['weekday_occurance_last'] = "son";
$l['every_year_on_day'] = "{1} {2} tarihinde her yıl tekrar eder";
$l['every_x_years_on_day'] = "{1} {2} tarihinde her {3} yılda bir tekrar eder";
$l['every_year_on_weekday'] = "Her yıl {3} 'de {1} {2}' de tekrar eder";
$l['every_x_year_on_weekday'] = "Her {4} yılda {3} 'da {1} {2}' de tekrar eder";
$l['delete_event'] = "Etkinliği Sil";
$l['delete_q'] = "Sil?";
$l['delete_1'] = "Bu etkinliği silmek için soldaki onay kutusunu işaretleyin ve ardından sağdaki düğmeye tıklayın.";
$l['delete_2'] = "<b>Not:</b> Bu işlem geri alınamaz.";
$l['delete_now'] = "Şimdi sil";
$l['delete_no_checkbox'] = "\"Delete\" onay kutusunu işaretlemediğiniz için etkinlik silinmedi.";
$l['jump_to_calendar'] = "Takvime atla:";
$l['select_calendar'] = "Takvim:";
$l['type_single'] = "Tek günlük etkinlik";
$l['type_ranged'] = "Değişen veya tekrarlanan etkinlik";
$l['enter_time'] = "Zaman:";
$l['start_time'] = "Başlangıç:";
$l['end_time'] = "Bitiş:";
$l['timezone'] = "Saat Dilimi:";
$l['ignore_timezone'] = "<strong>Saat dilimini yoksay:</strong> Bu etkinlik izleyicinin saat dilimini kullanmalıdır.";
$l['repeats'] = "Tekrarlar:";
$l['does_not_repeat'] = "Tekrar etmiyor";
$l['repeats_daily'] = "Günlük";
$l['repeats_weekdays'] = "Her hafta içi (Pzt-Cum)";
$l['repeats_weekly'] = "Haftalık";
$l['repeats_every'] = "Her tekrarlar";
$l['day_or_days'] = "gün (ler)";
$l['week_or_weeks_on'] = "hafta (lar)";
$l['repeats_monthly'] = "Aylık";
$l['repeats_yearly'] = "Yıllık";
$l['repeats_on_day'] = "Günde tekrarlar";
$l['of_every'] = "herşeyin";
$l['month_or_months'] = "ay(lar)";
$l['repeats_on_the'] = "Üzerinde tekrarlar";
$l['day_of_every'] = "her gün";
$l['repeats_on'] = "Üzerinde tekrarlar";
$l['every'] = "her";
$l['year_or_years'] = "yıl(lar)";
$l['of'] = "arasında";
$l['move_to_calendar'] = "Takvime Taşı:";
$l['weekly_overview'] = "Haftalık Genel Bakış";
$l['previous_week'] = "Önceki hafta";
$l['next_week'] = "Gelecek hafta";
$l['first'] = "İlk";
$l['second'] = "İkinci";
$l['third'] = "Üçüncü";
$l['fourth'] = "Dördüncü";
$l['last'] = "Son";
$l['all_day'] = "Tüm Gün";
$l['starts'] = "Başlangıç: ";
$l['finishes'] = "Bitiş: ";

$l['error_incorrectday'] = "Girdiğiniz gün görünmüyor. Lütfen geri dönün ve tekrar deneyin.";
$l['error_invalidevent'] = "Belirttiğiniz etkinlik geçersiz veya mevcut değil.";
$l['invalid_calendar'] = "Belirtilen takvim mevcut değil. Doğru sayfayı ziyaret ettiğinizden emin misiniz?";
$l['redirect_eventdeleted'] = "Etkinlik başarıyla silindi. <br /> Takvime yönlendiriliyorsunuz.";
$l['redirect_eventupdated'] = "Etkinlik başarıyla güncellendi. <br /> Etkinliğe yönlendiriliyorsunuz.";
$l['redirect_eventadded'] = "Etkinliğiniz başarıyla eklendi. <br /> Etkinliğe yönlendiriliyorsunuz.";
$l['redirect_eventadded_moderation'] = "Etkinliğiniz başarıyla eklendi ancak görünmeden önce bir forum yöneticisi tarafından denetlenmeyi gerektiriyor. <br /> Takvime yönlendiriliyorsunuz.";
$l['redirect_eventunapproved'] = "Etkinlik başarıyla onaylandı. <br /> Etkinliğe yönlendiriliyorsunuz.";
$l['redirect_eventapproved'] = "Etkinlik başarıyla onaylandı. <br /> Etkinliğe yönlendiriliyorsunuz.";
$l['redirect_eventmoved'] = "Etkinlik başarılı bir şekilde taşındı. <br /> Etkinliğe yönlendiriliyorsunuz.";
