<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['nav_editpost'] = "Konuyu düzenle";
$l['edit_post'] = "Bu Konuyu Düzenle";
$l['delete_post'] = "Konuyu Sil";
$l['delete_q'] = "Sil?";
$l['delete_1'] = "Bu konuyu silmek için soldaki onay kutusunu işaretleyin ve ardından sağdaki düğmeye tıklayın.";
$l['delete_2'] = "<b>Not:</b> Bu konu, bir konudaki ilk silinen konu ise, tüm başlığın silinmesine neden olur.";
$l['subject'] = "Konu Başlığı";
$l['your_message'] = "Konu İçeriği";
$l['post_options'] = "Konu Seçenekleri:";
$l['editreason'] = "Düzenleme Sebebi:";
$l['options_sig'] = "<strong>İmza:</strong> imzanızı ekleyin. (Sadece kayıtlı kullanıcılar)";
$l['options_emailnotify'] = "<strong>Eposta bildirimi:</strong> Yeni bir cevap geldiğinde e-posta alın. (Sadece kayıtlı kullanıcılar)";
$l['options_disablesmilies'] = "<strong>İfadeleri Devre Dışı Bırak:</strong> ifadelerin bu konuda gösterilmesini engelleyin.";
$l['preview_post'] = "Konuyu Önizle";
$l['update_post'] = "Konuyu Güncelle";
$l['poll'] = "Anket:";
$l['poll_desc'] = "İsteğe bağlı olarak, bu konuya bir anket ekleyebilirsiniz.";
$l['poll_check'] = "Bir anket göndermek istiyorum";
$l['num_options'] = "Seçenek sayısı:";
$l['max_options'] = "(Maksimum: {1})";
$l['delete_now'] = "Şimdi sil";
$l['edit_time_limit'] = "Üzgünüz, konuyu düzenleyemezsiniz. Yönetici, gönderilerin yalnızca {1} dakika içinde yayınlanabilmesi için düzenlenebileceğini belirtti.";
$l['no_prefix'] = "Önek Yok";

$l['redirect_nodelete'] = "Konu, \"sil\" onay kutusunu işaretlemediğiniz için silinmedi.";
$l['redirect_norestore'] = "\"Geri Yükleme\" onay kutusunu işaretlemediğiniz için konu geri yüklenmedi.";
$l['redirect_postedited'] = "Teşekkürler, bu konu düzenlendi.<br />";
$l['redirect_postedited_redirect'] = "Şimdi konuya geri döneceksiniz.";
$l['redirect_postedited_poll'] = "Teşekkürler, bu konu düzenlendi. <br />Bir anket göndermeyi seçtiğiniz için, şimdi anket oluşturma sayfasına yönlendirileceksiniz.";
$l['error_invalidpost'] = "Maalesef, geçersiz bir adres izlediniz. Lütfen belirtilen gönderinin var olduğundan emin olun ve tekrar deneyin.";
$l['redirect_threaddeleted'] = "Teşekkürler, konu silindi. <br /> Foruma geri döneceksiniz.";
$l['redirect_postdeleted'] = "Teşekkürler, mesaj silindi. <br /> Şimdi konuya geri döneceksiniz.";
$l['redirect_threadrestored'] = "Teşekkürler, konu geri yüklendi. <br /> Foruma geri döneceksiniz.";
$l['redirect_postrestored'] = "Teşekkürler, konu geri yüklendi. <br /> Şimdi geri döneceksiniz.";
$l['redirect_threadclosed'] = "Bu konudaki mevcut mesajları düzenleyemezsiniz, çünkü bir moderatör tarafından kapatılmıştır.";
$l['redirect_post_moderation'] = "Yönetici, tüm yazı düzenlemelerinin denetleme gerektirdiğini belirtti. Şimdi konuya geri döneceksiniz.";
$l['redirect_thread_moderation'] = "Yönetici, tüm içeriğin düzenlemesinin denetleme gerektirdiğini belirtti. Şimdi foruma geri döneceksiniz.";
$l['error_already_delete'] = "Maalesef, bu konu/mesaj zaten silinmiş.";

$l['thread_deleted'] = "Kalıcı Olarak Silinen Konu";
$l['post_deleted'] = "Kalıcı Olarak Silinmiş Mesaj";
$l['thread_soft_deleted'] = "Silinen Konu";
$l['post_soft_deleted'] = "Silinen Mesaj";
$l['thread_restored'] = "Geri Getirilen Konu";
$l['post_restored'] = "Geri Getirilen Yorum";

$l['error_already_deleted'] = 'Seçilen konu/mesaj zaten silindi.';
