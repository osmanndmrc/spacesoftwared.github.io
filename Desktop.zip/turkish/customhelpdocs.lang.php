<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Belge adı";
 * $l['d{hid}_desc'] = "Belge açıklaması";
 * $l['d{hid}_document'] = "Belge metni";
 */
