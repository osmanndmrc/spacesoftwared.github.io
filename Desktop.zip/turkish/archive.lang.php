<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['archive_fullversion'] = "Tam versiyon:";
$l['archive_replies'] = "Replylar";
$l['archive_reply'] = "Reply";
$l['archive_pages'] = "Sayfalar:";
$l['archive_note'] = "Şu anda tam olmayan bir versiyonun içeriğine bakıyorsunuz. <a href=\"{1}\">Tam versiyon</a>'a bakınız.";
$l['archive_nopermission'] = "Üzgünüz, bu kaynağa erişim izniniz yok.";
$l['error_nothreads'] = "Bu forumda şu anda konu yok.";
$l['error_nopermission'] = "Bu forumdaki konuları görüntüleme izniniz yok.";
$l['error_unapproved_thread'] = "Bu konu onaylanmadı. Bu konunun içeriğini görüntülemek için lütfen <a href=\"{1}\">Tam versiyon</a> a bakınız.";
$l['archive_not_found'] = "İstenen sayfa bu sunucuda bulunamadı.";
$l['error_mustlogin'] = "Bu modu görüntülemek için tüm kullanıcıların foruma giriş yapmış olması gerekir.";