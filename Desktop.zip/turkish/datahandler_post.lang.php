<?php
/**
 * MyBB 1.8.21 Türkçe Dil Paketi
 * Telif Hakkı 2019 mybbkitabi.com (ardayuce), Her Hakkı Saklıdır
 *
 */

$l['postdata_invalid_user_id'] = 'Kullanıcı kimliği mevcut değil. Lütfen geçerli bir kullanıcı kimliği girin.';
$l['postdata_firstpost_no_subject'] = 'Konu bir konu yok. Lütfen bir konu girin.';
$l['postdata_missing_subject'] = 'Konu eksik. Lütfen bir konu girin.';
$l['postdata_missing_message'] = 'Mesaj eksik. Lütfen bir mesaj girin.';
$l['postdata_message_too_long'] = 'Mesaj çok uzun. Lütfen {1} karakterden kısa bir mesaj girin (şu anda {2}).';
$l['postdata_message_too_short'] = 'Mesaj çok kısa. Lütfen {1} karakterden daha uzun bir mesaj girin.';
$l['postdata_subject_too_long'] = 'Konu çok uzun. Lütfen 85 karakterden kısa bir konu girin (şu anda {1}).';
$l['postdata_banned_username'] = 'Girdiğiniz kullanıcı adı kayıtlı olmayabilir. Lütfen farklı bir kullanıcı adı girin.';
$l['postdata_bad_characters_username'] = 'Girdiğiniz kullanıcı adı hatalı karakterler içeriyor. Lütfen farklı bir kullanıcı adı girin.';
$l['postdata_invalid_username_length'] = 'Girdiğiniz kullanıcı adı geçersiz. Lütfen {1} ve {2} karakterleri arasında bir kullanıcı adı girin.';
$l['postdata_username_exists'] = 'Girdiğiniz kullanıcı adı zaten var. Lütfen farklı bir kullanıcı adı girin.';
$l['postdata_post_flooding'] = 'Önceki bir mesajı gönderdikten sonra çok hızlı bir şekilde mesaj göndermeye çalışıyorsunuz. Lütfen {1} saniye daha bekleyin.';
$l['postdata_post_flooding_one_second'] = 'Önceki bir mesajı gönderdikten sonra çok hızlı bir şekilde mesaj göndermeye çalışıyorsunuz. Lütfen 1 saniye daha bekleyin.';
$l['postdata_too_many_images'] = 'Girdiğiniz iletide {1} resim varken, mesaj başına yalnızca {2} görüntüye izin verilir. Lütfen limitinize uymak için mesajınızdaki resim sayısını azaltın.';
$l['postdata_too_many_videos'] = 'Girdiğiniz mesaj {1} video içeriyor, mesaj başına sadece {2} videoya izin veriliyor. Lütfen limitinize uymak için mesajınızdaki video sayısını azaltın.';
$l['postdata_invalid_prefix'] = 'Seçilen önek geçersiz. Lütfen geçerli bir önek seçin.';
$l['postdata_require_prefix'] = 'Bu forumun ayarlanması için bir konu öneki gerekir. Lütfen geçerli bir önek seçin.';

$l['thread_closed'] = "Kapalı Konu";
$l['thread_opened'] = "Konu Açıldı";
$l['thread_stuck'] = "Sıkışmış Konu";
$l['thread_unstuck'] = "Sıkışmamış Konu";

